<?php
echo password_hash('admin71', PASSWORD_DEFAULT);
?>

<?php
/**
 * Configurações de Produção - Helmer Academy
 * Arquivo de configuração otimizado para ambiente de produção
 */

// Configurações de ambiente
define('APP_ENV', 'production');
define('APP_URL', 'https://seudominio.com'); // ALTERE PARA SEU DOMÍNIO
define('APP_DEBUG', false);

// Configurações de banco de dados
$host = "localhost";
$db   = "u853242961_helmer_db";
$user = "u853242961_helmer_user";
$pass = "Lucastav8012@";
$charset = "utf8mb4";

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::ATTR_PERSISTENT => true, // Conexão persistente para melhor performance
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    error_log("[PRODUCTION] [ERROR] [config_production.php] Falha na conexão com banco: " . $e->getMessage());
    die("Erro interno do servidor. Tente novamente em alguns minutos.");
}

// Configurações de cache
define('CACHE_ENABLED', true);
define('CACHE_TTL', 300);
define('CACHE_DIR', 'cache/');

// Configurações de segurança
define('SESSION_LIFETIME', 7200);
define('ENCRYPTION_KEY', 'your-secret-encryption-key-here'); // ALTERE ESTA CHAVE
define('JWT_SECRET', 'your-jwt-secret-key-here'); // ALTERE ESTA CHAVE

// Configurações de upload
define('UPLOAD_MAX_SIZE', 10485760); // 10MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp', 'pdf', 'zip', 'exe']);

// Configurações de log
define('LOG_LEVEL', 'error');
define('LOG_FILE', 'logs/error.log');
define('LOG_MAX_SIZE', 10485760); // 10MB

// Configurações de performance
define('ENABLE_GZIP', true);
define('ENABLE_CACHE_HEADERS', true);
define('CACHE_STATIC_ASSETS', true);

// Configurações PWA
define('PWA_NAME', 'Helmer Academy');
define('PWA_SHORT_NAME', 'Helmer Academy');
define('PWA_THEME_COLOR', '#e11d48');
define('PWA_BACKGROUND_COLOR', '#000000');

// Configurações de API
define('API_RATE_LIMIT', 100);
define('API_RATE_WINDOW', 3600);

// Headers de segurança
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    
    // CSP básico
    $csp = "default-src 'self'; " .
           "script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://unpkg.com https://cdnjs.cloudflare.com; " .
           "style-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://unpkg.com https://cdnjs.cloudflare.com; " .
           "img-src 'self' data: https:; " .
           "font-src 'self' https://cdnjs.cloudflare.com; " .
           "connect-src 'self'; " .
           "frame-ancestors 'none';";
    
    header("Content-Security-Policy: $csp");
}

// Configurações de sessão segura
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.cookie_samesite', 'Strict');

// Configurações de erro para produção
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', LOG_FILE);

// Função para log de erros personalizado
function logError($message, $context = []) {
    $timestamp = date('Y-m-d H:i:s');
    $contextStr = !empty($context) ? ' | Context: ' . json_encode($context) : '';
    $logMessage = "[$timestamp] [ERROR] [PRODUCTION] $message$contextStr" . PHP_EOL;
    
    error_log($logMessage, 3, LOG_FILE);
}

// Função para limpeza de cache
function clearCache() {
    if (is_dir(CACHE_DIR)) {
        $files = glob(CACHE_DIR . '*');
        foreach ($files as $file) {
            if (is_file($file)) {
                unlink($file);
            }
        }
        return true;
    }
    return false;
}

// Função para otimização de imagens
function optimizeImage($source, $destination, $quality = 85) {
    $info = getimagesize($source);
    if (!$info) return false;
    
    $mime = $info['mime'];
    
    switch ($mime) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            $image = imagecreatefrompng($source);
            break;
        case 'image/gif':
            $image = imagecreatefromgif($source);
            break;
        default:
            return false;
    }
    
    if (!$image) return false;
    
    $result = imagejpeg($image, $destination, $quality);
    imagedestroy($image);
    
    return $result;
}

// Função para compressão GZIP
function enableGzip() {
    if (ENABLE_GZIP && !ob_get_level()) {
        if (extension_loaded('zlib') && !headers_sent()) {
            ob_start('ob_gzhandler');
        }
    }
}

// Habilitar compressão se configurado
enableGzip();

// Função para headers de cache
function setCacheHeaders($maxAge = 3600) {
    if (ENABLE_CACHE_HEADERS && !headers_sent()) {
        header("Cache-Control: public, max-age=$maxAge");
        header("Expires: " . gmdate('D, d M Y H:i:s', time() + $maxAge) . " GMT");
    }
}

// Função para sanitização de dados
function sanitizeInput($data) {
    if (is_array($data)) {
        return array_map('sanitizeInput', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Função para validação de email
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// Função para geração de token seguro
function generateSecureToken($length = 32) {
    return bin2hex(random_bytes($length));
}

// Função para hash seguro de senha
function hashPassword($password) {
    return password_hash($password, PASSWORD_ARGON2ID, [
        'memory_cost' => 65536,
        'time_cost' => 4,
        'threads' => 3
    ]);
}

// Função para verificação de senha
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

// Configurações de timezone
date_default_timezone_set('America/Sao_Paulo');

// Configurações de memória e tempo
ini_set('memory_limit', '256M');
ini_set('max_execution_time', 30);

// Configurações de upload
ini_set('upload_max_filesize', '10M');
ini_set('post_max_size', '10M');
ini_set('max_file_uploads', 20);

// Configurações de sessão
ini_set('session.gc_maxlifetime', SESSION_LIFETIME);
ini_set('session.gc_probability', 1);
ini_set('session.gc_divisor', 100);

// Log de inicialização
logError("Sistema inicializado em modo produção");

?>
